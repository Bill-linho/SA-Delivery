CREATE DATABASE IF NOT EXISTS posto_saude_db
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE posto_saude_db;

CREATE TABLE pacientes (
    id_paciente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf CHAR(11) NOT NULL UNIQUE,
    data_nascimento DATE NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    endereco VARCHAR(150) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE profissionais (
    id_profissional INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    registro VARCHAR(30) NOT NULL UNIQUE,
    especialidade VARCHAR(60) NOT NULL,
    telefone VARCHAR(15) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE agendamentos (
    id_agendamento INT AUTO_INCREMENT PRIMARY KEY,
    id_paciente INT NOT NULL,
    id_profissional INT NOT NULL,
    data_consulta DATE NOT NULL,
    horario TIME NOT NULL,
    situacao ENUM('Agendada', 'Realizada', 'Cancelada') NOT NULL DEFAULT 'Agendada',
    FOREIGN KEY (id_paciente) REFERENCES pacientes(id_paciente)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    FOREIGN KEY (id_profissional) REFERENCES profissionais(id_profissional)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    UNIQUE (id_profissional, data_consulta, horario),
    UNIQUE (id_paciente, data_consulta, horario)
) ENGINE=InnoDB;

CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    login VARCHAR(30) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- Dados ficticios para testar a atividade.
INSERT INTO pacientes (nome, cpf, data_nascimento, telefone, endereco) VALUES
('Ana Souza', '11111111111', '2000-03-15', '47999990001', 'Rua A, 10'),
('Bruno Lima', '22222222222', '1995-07-20', '47999990002', 'Rua B, 20'),
('Carla Santos', '33333333333', '1988-11-05', '47999990003', 'Rua C, 30');

INSERT INTO profissionais (nome, registro, especialidade, telefone) VALUES
('Paulo Silva', 'CRM-SC 10001', 'Clinico geral', '47988880001'),
('Maria Costa', 'CRM-SC 10002', 'Pediatria', '47988880002'),
('Pedro Alves', 'CRM-SC 10003', 'Cardiologia', '47988880003');

INSERT INTO agendamentos (id_paciente, id_profissional, data_consulta, horario, situacao) VALUES
(1, 1, '2026-10-20', '08:00:00', 'Agendada'),
(2, 2, '2026-10-20', '09:00:00', 'Agendada'),
(3, 3, '2026-10-21', '10:00:00', 'Agendada');

-- Os tres usuarios de demonstracao usam a senha de teste: teste123.
-- O valor armazenado abaixo e o hash gerado por password_hash() no PHP.
INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Caio Nolli', 'admin', '$2y$10$wHqoEGJJrC038hY6RY5rTuBeqgQxpv.FCB.3g.FQvWZUNWGTc5UMe'),
('Ana Souza', 'ana', '$2y$10$wHqoEGJJrC038hY6RY5rTuBeqgQxpv.FCB.3g.FQvWZUNWGTc5UMe'),
('Bruno Lima', 'bruno', '$2y$10$wHqoEGJJrC038hY6RY5rTuBeqgQxpv.FCB.3g.FQvWZUNWGTc5UMe');
