<?php
require 'funcoes.php';
proteger();
require 'conexao.php';
$erro = '';
$agendamento = ['id_agendamento' => '', 'id_paciente' => '', 'id_profissional' => '', 'data_consulta' => '', 'horario' => '', 'situacao' => 'Agendada'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validar_token();
    $id = (int) ($_POST['id_agendamento'] ?? 0);
    $agendamento = ['id_agendamento' => $id, 'id_paciente' => (int) ($_POST['id_paciente'] ?? 0),
        'id_profissional' => (int) ($_POST['id_profissional'] ?? 0), 'data_consulta' => $_POST['data_consulta'] ?? '',
        'horario' => $_POST['horario'] ?? '', 'situacao' => $_POST['situacao'] ?? ''];
    if (!$agendamento['id_paciente'] || !$agendamento['id_profissional'] || !data_valida($agendamento['data_consulta']) ||
        !preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $agendamento['horario']) ||
        !in_array($agendamento['situacao'], ['Agendada', 'Realizada', 'Cancelada'], true)) {
        $erro = 'Selecione o paciente e o profissional e informe uma data, horário e situação válidos.';
    } else {
        try {
            $valores = [$agendamento['id_paciente'], $agendamento['id_profissional'], $agendamento['data_consulta'], $agendamento['horario'], $agendamento['situacao']];
            if ($id > 0) {
                $sql = 'UPDATE agendamentos SET id_paciente = ?, id_profissional = ?, data_consulta = ?, horario = ?, situacao = ? WHERE id_agendamento = ?';
                $valores[] = $id;
            } else {
                $sql = 'INSERT INTO agendamentos (id_paciente, id_profissional, data_consulta, horario, situacao) VALUES (?, ?, ?, ?, ?)';
            }
            $pdo->prepare($sql)->execute($valores);
            header('Location: agendamentos.php');
            exit;
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $erro = $e->getCode() === '23000' ? 'Paciente ou profissional indisponível nesse horário, ou cadastro não encontrado.' : 'Não foi possível salvar o agendamento.';
        }
    }
}
if (isset($_GET['editar'])) {
    $consulta = $pdo->prepare('SELECT * FROM agendamentos WHERE id_agendamento = ?');
    $consulta->execute([(int) $_GET['editar']]);
    $agendamento = $consulta->fetch();
    if (!$agendamento) {
        http_response_code(404);
        exit('Agendamento não encontrado. <a href="agendamentos.php">Voltar</a>');
    }
    $agendamento['horario'] = substr($agendamento['horario'], 0, 5);
}
$pacientes = $pdo->query('SELECT id_paciente, nome FROM pacientes ORDER BY nome')->fetchAll();
$profissionais = $pdo->query('SELECT id_profissional, nome FROM profissionais ORDER BY nome')->fetchAll();
$agendamentos = $pdo->query('SELECT a.*, p.nome AS paciente, pr.nome AS profissional FROM agendamentos a
    JOIN pacientes p ON p.id_paciente = a.id_paciente
    JOIN profissionais pr ON pr.id_profissional = a.id_profissional
    ORDER BY a.data_consulta, a.horario')->fetchAll();
topo('Agendamentos');
voltar();
?>
<p><?= texto($erro) ?></p>
<h2><?= $agendamento['id_agendamento'] ? 'Atualizar agendamento' : 'Cadastrar agendamento' ?></h2>
<form method="post" action="agendamentos.php">
    <?php token(); ?>
    <input type="hidden" name="id_agendamento" value="<?= texto($agendamento['id_agendamento']) ?>">
    <p><label>Paciente: <select name="id_paciente" required>
        <option value="">Selecione</option>
        <?php foreach ($pacientes as $item): ?>
        <option value="<?= $item['id_paciente'] ?>" <?= $agendamento['id_paciente'] == $item['id_paciente'] ? 'selected' : '' ?>><?= texto($item['nome']) ?></option>
        <?php endforeach; ?>
    </select></label></p>
    <p><label>Profissional: <select name="id_profissional" required>
        <option value="">Selecione</option>
        <?php foreach ($profissionais as $item): ?>
        <option value="<?= $item['id_profissional'] ?>" <?= $agendamento['id_profissional'] == $item['id_profissional'] ? 'selected' : '' ?>><?= texto($item['nome']) ?></option>
        <?php endforeach; ?>
    </select></label></p>
    <p><label>Data: <input type="date" name="data_consulta" value="<?= texto($agendamento['data_consulta']) ?>" required></label></p>
    <p><label>Horário: <input type="time" name="horario" value="<?= texto($agendamento['horario']) ?>" required></label></p>
    <p><label>Situação: <select name="situacao">
        <?php foreach (['Agendada', 'Realizada', 'Cancelada'] as $situacao): ?>
        <option <?= $agendamento['situacao'] === $situacao ? 'selected' : '' ?>><?= texto($situacao) ?></option>
        <?php endforeach; ?>
    </select></label></p>
    <button type="submit">Salvar agendamento</button> <a href="agendamentos.php">Limpar / cancelar</a>
</form>
<h2>Lista de agendamentos</h2>
<table border="1" cellpadding="5">
    <tr><th>Data</th><th>Horário</th><th>Paciente</th><th>Profissional</th><th>Situação</th><th>Ação</th></tr>
    <?php foreach ($agendamentos as $item): ?>
    <tr><td><?= date('d/m/Y', strtotime($item['data_consulta'])) ?></td><td><?= texto(substr($item['horario'], 0, 5)) ?></td>
        <td><?= texto($item['paciente']) ?></td><td><?= texto($item['profissional']) ?></td><td><?= texto($item['situacao']) ?></td>
        <td><a href="agendamentos.php?editar=<?= $item['id_agendamento'] ?>">Atualizar</a></td></tr>
    <?php endforeach; ?>
</table>
<?php if (!$agendamentos): ?><p>Nenhum agendamento cadastrado.</p><?php endif; ?>
<?php fim(); ?>
