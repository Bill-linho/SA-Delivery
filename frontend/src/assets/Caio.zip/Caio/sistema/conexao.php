<?php
$host = '127.0.0.1';
$porta = '3306';
$banco = 'posto_saude_db';
$usuario = 'root';
$senha = '';

try {
    $pdo = new PDO("mysql:host=$host;port=$porta;dbname=$banco;charset=utf8mb4", $usuario, $senha, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(503);
    exit('Não foi possível conectar ao banco. Confira se o MySQL está ligado e se o banco foi importado.');
}
