<?php
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();
date_default_timezone_set('America/Sao_Paulo');
set_exception_handler(function ($erro) {
    error_log($erro->getMessage());
    http_response_code(500);
    exit('Não foi possível concluir a operação. Volte à página principal e tente novamente.');
});

function texto($valor) {
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function proteger() {
    if (!isset($_SESSION['id_usuario']) || time() - ($_SESSION['ultimo_acesso'] ?? 0) > 1800) {
        $_SESSION = [];
        session_regenerate_id(true);
        header('Location: login.php');
        exit;
    }
    $_SESSION['ultimo_acesso'] = time();
}

function token() {
    if (empty($_SESSION['token'])) {
        $_SESSION['token'] = bin2hex(random_bytes(32));
    }
    echo '<input type="hidden" name="token" value="' . texto($_SESSION['token']) . '">';
}

function validar_token() {
    if (!hash_equals($_SESSION['token'] ?? '', $_POST['token'] ?? '') || empty($_SESSION['token'])) {
        http_response_code(403);
        exit('Formulário expirado. Volte à página e tente novamente.');
    }
}

function data_valida($data) {
    $d = DateTime::createFromFormat('!Y-m-d', $data);
    return $d && $d->format('Y-m-d') === $data;
}

function telefone_valido($telefone) {
    return preg_match('/^[0-9]{10,11}$/', $telefone);
}

function topo($titulo) {
    echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . texto($titulo) . '</title></head><body><h1>' . texto($titulo) . '</h1>';
}

function voltar() {
    echo '<p><a href="index.php">Voltar para a página principal</a></p>';
}

function fim() {
    echo '</body></html>';
}
