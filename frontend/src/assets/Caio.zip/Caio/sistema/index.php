<?php
require 'funcoes.php';
proteger();
topo('Posto de saúde');
?>
<p>Usuário: <?= texto($_SESSION['nome_usuario']) ?></p>
<ul>
    <li><a href="pacientes.php">Pacientes</a></li>
    <li><a href="profissionais.php">Profissionais de saúde</a></li>
    <li><a href="agendamentos.php">Agendamentos</a></li>
</ul>
<form method="post" action="sair.php">
    <?php token(); ?>
    <button type="submit">Sair</button>
</form>
<?php fim(); ?>
