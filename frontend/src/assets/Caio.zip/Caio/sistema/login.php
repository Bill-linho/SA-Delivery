<?php
require 'funcoes.php';
require 'conexao.php';
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validar_token();
    $login = trim($_POST['login'] ?? '');
    $senha = $_POST['senha'] ?? '';
    try {
        $consulta = $pdo->prepare('SELECT id_usuario, nome, senha_hash FROM usuarios WHERE login = ?');
        $consulta->execute([$login]);
        $usuario = $consulta->fetch();
        if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
            session_regenerate_id(true);
            $_SESSION = [
                'id_usuario' => $usuario['id_usuario'],
                'nome_usuario' => $usuario['nome'],
                'ultimo_acesso' => time()
            ];
            header('Location: index.php');
            exit;
        }
        $erro = 'Usuário ou senha inválidos.';
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $erro = 'Não foi possível entrar. Tente novamente.';
    }
}
topo('Posto de saúde - Login');
?>
<p><?= texto($erro) ?></p>
<form method="post">
    <?php token(); ?>
    <p><label>Usuário: <input name="login" maxlength="30" autocomplete="username" required></label></p>
    <p><label>Senha: <input type="password" name="senha" autocomplete="current-password" required></label></p>
    <button type="submit">Entrar</button>
</form>
<?php fim(); ?>
