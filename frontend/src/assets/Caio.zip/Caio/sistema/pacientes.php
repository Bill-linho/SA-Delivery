<?php
require 'funcoes.php';
proteger();
require 'conexao.php';
$erro = '';
$paciente = ['id_paciente' => '', 'nome' => '', 'cpf' => '', 'data_nascimento' => '', 'telefone' => '', 'endereco' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validar_token();
    $id = (int) ($_POST['id_paciente'] ?? 0);
    if (isset($_POST['excluir'])) {
        try {
            $consulta = $pdo->prepare('DELETE FROM pacientes WHERE id_paciente = ?');
            $consulta->execute([$id]);
            header('Location: pacientes.php');
            exit;
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $erro = $e->getCode() === '23000' ? 'Este paciente possui agendamentos e não pode ser excluído.' : 'Não foi possível excluir o paciente.';
        }
    } else {
        $paciente = ['id_paciente' => $id, 'nome' => trim($_POST['nome'] ?? ''), 'cpf' => trim($_POST['cpf'] ?? ''),
            'data_nascimento' => $_POST['data_nascimento'] ?? '', 'telefone' => trim($_POST['telefone'] ?? ''), 'endereco' => trim($_POST['endereco'] ?? '')];
        if ($paciente['nome'] === '' || strlen($paciente['nome']) > 100 || !preg_match('/^[0-9]{11}$/', $paciente['cpf']) ||
            !data_valida($paciente['data_nascimento']) || $paciente['data_nascimento'] > date('Y-m-d') ||
            !telefone_valido($paciente['telefone']) || $paciente['endereco'] === '' || strlen($paciente['endereco']) > 150) {
            $erro = 'Preencha os campos corretamente. Use CPF com 11 números, telefone com 10 ou 11 números e uma data de nascimento válida.';
        } else {
            try {
                $valores = [$paciente['nome'], $paciente['cpf'], $paciente['data_nascimento'], $paciente['telefone'], $paciente['endereco']];
                if ($id > 0) {
                    $sql = 'UPDATE pacientes SET nome = ?, cpf = ?, data_nascimento = ?, telefone = ?, endereco = ? WHERE id_paciente = ?';
                    $valores[] = $id;
                } else {
                    $sql = 'INSERT INTO pacientes (nome, cpf, data_nascimento, telefone, endereco) VALUES (?, ?, ?, ?, ?)';
                }
                $pdo->prepare($sql)->execute($valores);
                header('Location: pacientes.php');
                exit;
            } catch (PDOException $e) {
                error_log($e->getMessage());
                $erro = $e->getCode() === '23000' ? 'Já existe um paciente com esse CPF.' : 'Não foi possível salvar o paciente.';
            }
        }
    }
}
if (isset($_GET['editar'])) {
    $consulta = $pdo->prepare('SELECT * FROM pacientes WHERE id_paciente = ?');
    $consulta->execute([(int) $_GET['editar']]);
    $paciente = $consulta->fetch();
    if (!$paciente) {
        http_response_code(404);
        exit('Paciente não encontrado. <a href="pacientes.php">Voltar</a>');
    }
}
$busca = trim($_GET['busca'] ?? '');
$consulta = $pdo->prepare('SELECT id_paciente, nome, telefone FROM pacientes WHERE nome LIKE ? ORDER BY nome');
$consulta->execute(['%' . $busca . '%']);
$pacientes = $consulta->fetchAll();
topo('Pacientes');
voltar();
?>
<p><?= texto($erro) ?></p>
<h2><?= $paciente['id_paciente'] ? 'Editar paciente' : 'Cadastrar paciente' ?></h2>
<form method="post" action="pacientes.php">
    <?php token(); ?>
    <input type="hidden" name="id_paciente" value="<?= texto($paciente['id_paciente']) ?>">
    <p><label>Nome completo: <input name="nome" maxlength="100" value="<?= texto($paciente['nome']) ?>" required></label></p>
    <p><label>CPF (somente números): <input name="cpf" pattern="[0-9]{11}" maxlength="11" value="<?= texto($paciente['cpf']) ?>" required></label></p>
    <p><label>Data de nascimento: <input type="date" name="data_nascimento" max="<?= date('Y-m-d') ?>" value="<?= texto($paciente['data_nascimento']) ?>" required></label></p>
    <p><label>Telefone com DDD (somente números): <input name="telefone" pattern="[0-9]{10,11}" maxlength="11" value="<?= texto($paciente['telefone']) ?>" required></label></p>
    <p><label>Endereço: <input name="endereco" maxlength="150" value="<?= texto($paciente['endereco']) ?>" required></label></p>
    <button type="submit">Salvar paciente</button> <a href="pacientes.php">Limpar / cancelar</a>
</form>
<h2>Lista de pacientes</h2>
<form method="get">
    <label>Buscar pelo nome: <input name="busca" value="<?= texto($busca) ?>"></label>
    <button type="submit">Buscar</button> <a href="pacientes.php">Mostrar todos</a>
</form>
<table border="1" cellpadding="5">
    <tr><th>Nome</th><th>Telefone</th><th>Ações</th></tr>
    <?php foreach ($pacientes as $item): ?>
    <tr>
        <td><?= texto($item['nome']) ?></td><td><?= texto($item['telefone']) ?></td>
        <td><a href="pacientes.php?editar=<?= $item['id_paciente'] ?>">Editar</a>
            <form method="post" action="pacientes.php">
                <?php token(); ?>
                <input type="hidden" name="id_paciente" value="<?= $item['id_paciente'] ?>">
                <button type="submit" name="excluir">Excluir</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php if (!$pacientes): ?><p>Nenhum paciente encontrado.</p><?php endif; ?>
<?php fim(); ?>
