<?php
require 'funcoes.php';
proteger();
require 'conexao.php';
$erro = '';
$profissional = ['id_profissional' => '', 'nome' => '', 'registro' => '', 'especialidade' => '', 'telefone' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validar_token();
    $id = (int) ($_POST['id_profissional'] ?? 0);
    $profissional = ['id_profissional' => $id, 'nome' => trim($_POST['nome'] ?? ''), 'registro' => trim($_POST['registro'] ?? ''),
        'especialidade' => trim($_POST['especialidade'] ?? ''), 'telefone' => trim($_POST['telefone'] ?? '')];
    if ($profissional['nome'] === '' || strlen($profissional['nome']) > 100 || $profissional['registro'] === '' || strlen($profissional['registro']) > 30 ||
        $profissional['especialidade'] === '' || strlen($profissional['especialidade']) > 60 || !telefone_valido($profissional['telefone'])) {
        $erro = 'Preencha todos os campos corretamente. O telefone deve ter 10 ou 11 números.';
    } else {
        try {
            $valores = [$profissional['nome'], $profissional['registro'], $profissional['especialidade'], $profissional['telefone']];
            if ($id > 0) {
                $sql = 'UPDATE profissionais SET nome = ?, registro = ?, especialidade = ?, telefone = ? WHERE id_profissional = ?';
                $valores[] = $id;
            } else {
                $sql = 'INSERT INTO profissionais (nome, registro, especialidade, telefone) VALUES (?, ?, ?, ?)';
            }
            $pdo->prepare($sql)->execute($valores);
            header('Location: profissionais.php');
            exit;
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $erro = $e->getCode() === '23000' ? 'Já existe um profissional com esse registro.' : 'Não foi possível salvar o profissional.';
        }
    }
}
if (isset($_GET['editar'])) {
    $consulta = $pdo->prepare('SELECT * FROM profissionais WHERE id_profissional = ?');
    $consulta->execute([(int) $_GET['editar']]);
    $profissional = $consulta->fetch();
    if (!$profissional) {
        http_response_code(404);
        exit('Profissional não encontrado. <a href="profissionais.php">Voltar</a>');
    }
}
$profissionais = $pdo->query('SELECT * FROM profissionais ORDER BY nome')->fetchAll();
topo('Profissionais de saúde');
voltar();
?>
<p><?= texto($erro) ?></p>
<h2><?= $profissional['id_profissional'] ? 'Consultar / editar profissional' : 'Cadastrar profissional' ?></h2>
<form method="post" action="profissionais.php">
    <?php token(); ?>
    <input type="hidden" name="id_profissional" value="<?= texto($profissional['id_profissional']) ?>">
    <p><label>Nome completo: <input name="nome" maxlength="100" value="<?= texto($profissional['nome']) ?>" required></label></p>
    <p><label>Registro profissional: <input name="registro" maxlength="30" value="<?= texto($profissional['registro']) ?>" required></label></p>
    <p><label>Especialidade: <input name="especialidade" maxlength="60" value="<?= texto($profissional['especialidade']) ?>" required></label></p>
    <p><label>Telefone com DDD (somente números): <input name="telefone" pattern="[0-9]{10,11}" maxlength="11" value="<?= texto($profissional['telefone']) ?>" required></label></p>
    <button type="submit">Salvar profissional</button> <a href="profissionais.php">Limpar / cancelar</a>
</form>
<h2>Lista de profissionais</h2>
<table border="1" cellpadding="5">
    <tr><th>Nome</th><th>Especialidade</th><th>Ação</th></tr>
    <?php foreach ($profissionais as $item): ?>
    <tr><td><?= texto($item['nome']) ?></td><td><?= texto($item['especialidade']) ?></td>
        <td><a href="profissionais.php?editar=<?= $item['id_profissional'] ?>">Consultar / editar</a></td></tr>
    <?php endforeach; ?>
</table>
<?php if (!$profissionais): ?><p>Nenhum profissional cadastrado.</p><?php endif; ?>
<?php fim(); ?>
